/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.time.LocalDateTime;
import java.util.Date;

/**Descripcion de la clase soat
 *
 * 
 */
public class Soat {
    /**
     * Atributos de la calse soat
     */
    private String aseguradora;
    private Date fInicio, fFinal;
    /**
     * Metodo Constructor de la clase soat
     * @param aseguradora
     * @param fInicio
     * @param fFinal 
     */
    public Soat(String aseguradora, Date fInicio, Date fFinal) {
        this.aseguradora = aseguradora;
        this.fInicio = fInicio;
        this.fFinal = fFinal;
    }

    /**
     * Metodo para obtener la aseguradora
     * @return 
     */
    public String getAseguradora() {
        return aseguradora;
    }
    /**
     * Metodo para modificar la aseguradora
     * @param aseguradora 
     */
    public void setAseguradora(String aseguradora) {
        this.aseguradora = aseguradora;
    }
    /*
    *Metodo para obtener la fecha de inicio
    */
    public Date getfInicio() {
        return fInicio;
    }
    /**
     * Metodo para modificar la fecha de inicio
     * @param fInicio 
     */
    public void setfInicio(Date fInicio) {
        this.fInicio = fInicio;
    }
    /**
     * Metodo para obtener la fecha final
     * @return 
     */
    public Date getfFinal() {
        return fFinal;
    }
    /**
     * Metodo para modificar la fecha final
     * @param fFinal 
     */
    public void setfFinal(Date fFinal) {
        this.fFinal = fFinal;
    }
    /**
     * Metodo ToString
     * @return 
     */
    @Override
    public String toString() {
        return "\n\tAseguradora: " + aseguradora + "\n\tFecha de Inicio: " + fInicio + ", Fecha de Vencimiento: " + fFinal + "\n\n";
    }
    
    
}
