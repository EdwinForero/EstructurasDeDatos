package Entities;

import java.util.Date;
import DataStructures.Stack;
import java.util.Iterator;

/**
 * Descripcion de la clase log
 */
public class Log {

    /**
     * Declaracion de atributos de la clase log
     */
    private Vehicle vehiculo;
    private Stack faltas;
    private long saldoT;

    /**
     * Metodo constructor de la clase log
     *
     * @param vehiculo
     */
    public Log(Vehicle vehiculo) {
        this.vehiculo = vehiculo;
        faltas = new Stack();
        saldoT = 0;
        
    }

    /**
     * Metodo soatVencido
     *
     * @param date
     * @return
     */
    public boolean soatVencido(Date date) {

        return date.after(vehiculo.getSoat().getfFinal());
    }

    /**
     * Metodo picoplaca de tipo boolean
     *
     * @param date
     * @return
     */
    public boolean picoPlaca(Date date) {

        char a = vehiculo.getPlaca().charAt(vehiculo.getPlaca().length() - 1);
        
        float minutos = date.getMinutes() / 60f;
        float hora = date.getHours() + minutos;
        
        byte cifra = Byte.parseByte(a + "");
        byte dia = (byte) date.getDate();
        byte dsemana = (byte)date.getDay();

        if (dsemana == 0 || dsemana == 6) {
            return false;
        } else {
            boolean diaVsPlaca = (cifra % 2 == 0 && dia % 2 == 0) || (cifra % 2 == 1 && dia % 2 == 1);
            return  diaVsPlaca && ((hora >= 6 && hora <= 8.5) || (hora >= 15 && hora <= 19));
        }

    }

    /**
     * Metodo Newfault que no retorna nada
     */
    public void newFault() {
        Date date = new Date();
        
        boolean pYp = picoPlaca(date), sV = soatVencido(date);
        
        Fault falta = new Fault(pYp, sV, date);
        faltas.push(falta);

        Iterator it = faltas.iterator();
        saldoT = 0;
        while (it.hasNext()) {
            Fault lol = (Fault) it.next();
            saldoT += lol.getSaldo();
        }
    }

    /**
     * Metodo getVehiculo
     *
     * @return
     */
    public Vehicle getVehiculo() {
        return vehiculo;
    }

    /**
     * Metodo para modificar el vehiculo
     *
     * @param vehiculo
     */
    public void setVehiculo(Vehicle vehiculo) {
        this.vehiculo = vehiculo;
    }

    /**
     * Metodo para obtener las faltas
     *
     * @return
     */
    public Stack getFaltas() {
        return faltas;
    }

    /**
     * Metodo para obtener el saldo
     *
     * @return
     */
    public long getSaldoT() {
        return saldoT;
    }

    /**
     * Metodo toString para la impresion
     *
     * @return
     */
    @Override
    public String toString() {
        return "\n\n____________________Información del registro____________________\n"
                + "\n--Vehículo:\n" + vehiculo
                + "--Comparendos:\n" + faltas.toString()
                + "--Deuda Total: $" + saldoT;
    }

}
