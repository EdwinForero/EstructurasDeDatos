/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.util.Objects;
/**
 * Descripcion de la clase Person
 * @author david
 */
public class Person {
    /**
     *  Declaracion de atributos
     */
    private String nombre, direccion,email;
    private long id, numTel;
    /**
     * Constructor de la clase person
     * @param nombre
     * @param direccion
     * @param email
     * @param id
     * @param numTel 
     */
    public Person(String nombre, String direccion, String email, long id, long numTel) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.email = email;
        this.id = id;
        this.numTel = numTel;
    }
    /**
     * Metodo para obtener el nombre
     * @return 
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Metodo para obtener la direccion
     * @return 
     */
    public String getDireccion() {
        return direccion;
    }
    /**
     * Metodo para obtener el email
     * @return 
     */
    public String getEmail() {
        return email;
    }
    /**
     * Metodo para obtener la identificacion
     * @return 
     */
    public long getId() {
        return id;
    }
    /**
     * Metodo para obtener el numero de telefono
     * @return 
     */
    public long getNumTel() {
        return numTel;
    }
    /**
     * Metodo para modificar el nombre
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Metodo para modificar la direccion
     * @param direccion 
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    /**
     * Metodo para modifcar el email
     * @param email 
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * Metodo para modificar la identificacion
     * @param id 
     */
    public void setId(long id) {
        this.id = id;
    }
    /*
    Metodo para modificar el numero de telefono
    */
    public void setNumTel(long numTel) {
        this.numTel = numTel;
    }
    /**
     * Metodo toString para la impresion de datos
     * @return 
     */
    @Override
    public String toString() {
        return "\n\n\tNombre del propietario: " + nombre + "\n\tDireccion: " + direccion + "\n\tEmail: " + email + "\n\tId: " + id + "\n\tNúmero de Teléfono: " + numTel + '\n';
    }
    
    
}
