/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;
/**Descripcion de la clase vehiculo
 * 
 * @author
 */
public class Vehicle{
    /**
     * Atributos de la clase vehicle
     */
    private String placa, marca, modelo, cilindrada, color, servicio;
    private Person propietario;
    private Soat soat;
    /**
     * Metodo constructor de la clase vehicle
     * @param placa
     * @param marca
     * @param modelo
     * @param cilindrada
     * @param color
     * @param servicio
     * @param propietario
     * @param soat 
     */
    public Vehicle(String placa, String marca, String modelo, String cilindrada, String color, String servicio, Person propietario, Soat soat) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.servicio = servicio;
        this.propietario = propietario;
        this.soat = soat;
        this.cilindrada = cilindrada;
    }
    /**
     * Metodo para obtener el soat
     * @return 
     */
    public Soat getSoat() {
        return soat;
    }
    /**
     * Metodo para modificar el soat
     * @param soat 
     */
    public void setSoat(Soat soat) {
        this.soat = soat;
    }
    /**
     * Metodo para obtener la placa
     * @return 
     */
    public String getPlaca() {
        return placa;
    }
    /**
     * Metodo set para modificar la placa
     * @param placa 
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }
    /**
     * Metodo para obtener la marca
     * @return 
     */
    public String getMarca() {
        return marca;
    }
    /**
     * Metodo set para modificar la marca
     * @param marca 
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    /**
     * Metodo ger para obtener el modelo
     * @return 
     */
    public String getModelo() {
        return modelo;
    }
    /**
     * Metodo para modificar el modelo
     * @param modelo 
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    /**
     * Metodo para obtener el color
     * @return 
     */
    public String getColor() {
        return color;
    }
    /**
     * Metodo para modificar el color
     * @param color 
     */
    public void setColor(String color) {
        this.color = color;
    }
    /**
     * Metodo para obtener el servicio
     * @return 
     */
    public String getServicio() {
        return servicio;
    }
    /**
     * Metodo para modificar el servicio
     * @param servicio 
     */
    public void setServicio(String servicio) {
        this.servicio = servicio;
    }
    /**
     * Metodo para obtener el propietario
     * @return 
     */
    public Person getPropietario() {
        return propietario;
    }
    /**
     * Metodo para modificar el propietario
     * @param propietario 
     */
    public void setPropietario(Person propietario) {
        this.propietario = propietario;
    }
    /**
     * Metodo ToString
     * @return 
     */
    @Override
    public String toString() {
        return "\n\tPlaca: " + placa + "\n\tMarca: " + marca 
                + "\n\tModelo: " + modelo + "\n\tColor: " + color + "\n\tServicio: " + servicio + "\n\tCilindrada"
                + cilindrada + propietario
                + "--Soat:\n" + soat;
    }

}
