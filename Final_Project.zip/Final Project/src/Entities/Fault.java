/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.util.Date;

/**Descripcion de la clase fault
 *
 * 
 */
public final class Fault {
    /**
     * Declaracion de los atributos
     */
    private boolean PYP, SV;
    private Date fecha;
    private long saldo;
    /**
     * Constructor de la clase fault
     * @param PYP
     * @param SV
     * @param fecha 
     */
    public Fault(boolean PYP, boolean SV, Date fecha) {
        this.PYP = PYP;
        this.SV = SV;
        this.fecha = fecha;
        saldo = calcularDeuda();
    }
    /**
     * Metodo boolean para el pico y placa
     * @return 
     */
    public boolean isPYP() {
        return PYP;
    }
    /**
     * Metodo get para el soat vencido
     * @return 
     */
    public boolean isSV() {
        return SV;
    }
    /**
     * Metodo set de pico y placa
     * @param PYP 
     */
    public void setPYP(boolean PYP) {
        this.PYP = PYP;
    }
    /**
     * Metodo de set de soat vencido
     * @param SV 
     */
    public void setSV(boolean SV) {
        this.SV = SV;
    }
    /**
     * metodo para obtener la fecha
     * @return 
     */
    public Date getFecha() {
        return fecha;
    }
    /**
     * Metodo para obtener el saldo
     * @return 
     */
    public long getSaldo() {
        return saldo;
    }
    /**
     * Metodo set para modificar la fecha
     * @param fecha 
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    /**
     * Metodo set para modificar el saldo
     * @param saldo 
     */
    public void setSaldo(long saldo) {
        this.saldo = saldo;
    }
    /**
     * metodo para calcular la deuda
     * @return 
     */
    public long calcularDeuda(){
        long a = 0;
        if(PYP){
            a+=438900;
        }
        if(SV){
            a+=877800;
        }
        return a;
    }
    /**
     * Metodo toString para imprimir los datos
     * @return 
     */
    @Override
    public String toString() {
        String s = "\nSoat vencido: $877800", p = "\nPico y Placa: $438900";
        String a = "";
        if(SV || PYP){
            a += "\nFecha del comparendo: " + fecha + "\n\nDeuda parcial del comparendo: $" + saldo;
        }
        return (SV?s:"") + (PYP?p:"") + a
                + "\n";
    }

    
    
    
}
