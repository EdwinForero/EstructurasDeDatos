/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities;

/**
 *
 * @author edwin
 */
public class RndInfo {

    /**
     * Metodo para generar placas aleatorias
     * @return 
     */
    public static String RPlacas() {
        String num = "";
        String abe = "";
        char[] abecedario = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
            'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        for (byte i = 0; i < 3; i++) {
            num += (int) (Math.random() * 9);
            abe += abecedario[(int) (Math.floor(Math.random() * ((abecedario.length - 1) - 0 + 1) + 0))];
        }

        return abe + " " + num;
    }
//Marca
    /**
     * Metodo para generar la marca aleatoria
     * @param capacidad
     * @return 
     */
    public static String[] RMarca(int capacidad) {
        String[] Rmarca = new String[capacidad];
        String[] marca = {"Mazda", "Porsche", "Ferrari", "Mitsubichi", "Renault", "Kia", "Toyota", "Volkswagen",
             "Ford", "Nissan", "Hyundai", "Chevrolet", "Mercedes-Benz", "BMW", "Audi", "Maserati", "Tesla", "Lamborghini",
             "Alfa Romeo", "Cadillac", "Citroen", "Daewoo", "Dodge", "Fiat", "Hummer", "Jaguar", "Jeep", "Land Rover"};
        for (int i = 0; i < capacidad; i++) {
            Rmarca[i] = marca[(int) (Math.floor(Math.random() * ((marca.length - 1) - 0 + 1) + 0))];
        }
        return Rmarca;
    }
//Modelo
    /**
     * Metodo para generar modelo aleatoriamente
     * @param capacidad
     * @return 
     */
    public static String[] RModelo(int capacidad) {
        String[] RModelo = new String[capacidad];
        String[] modelo = {"2017", "2015", "2001", "2002", "2003", "2005", "2006", "2007", "2008", "2011",
            "2020", "2000", "2010", "2018", "2020", "2019",};
        for (int i = 0; i < capacidad; i++) {
            RModelo[i] = modelo[(int) (Math.floor(Math.random() * ((modelo.length - 1) - 0 + 1) + 0))];
        }
        return RModelo;
    }

//Cilindraje(tal vez)
//Color
    /**
     * Metodo para generar el color aleatoriamente
     * @param capacidad
     * @return 
     */
    public static String[] RColor(int capacidad) {
        String[] RColor = new String[capacidad];
        String[] color = {"Rojo", "Negro", "Azul", "Amarillo", "Magenta", "Azul Oscuro", "Rosa", "Morado", "Naranja", "Verde Claro",
            "Verde Oscuro", "Blanco", "Azul Claro", "Dorado", "Gris", "Gris Plata", "Rojo Oscuro", "Rojo Claro"};
        for (int i = 0; i < capacidad; i++) {
            RColor[i] = color[(int) (Math.floor(Math.random() * ((color.length - 1) - 0 + 1) + 0))];
        }
        return RColor;
    }
//Servicio
    /**
     * Metodo para obtener el servicio aleatoriamente
     * @param capacidad
     * @return 
     */
    public static String[] RServicio(int capacidad) {
        String[] RServicio = new String[capacidad];
        String[] servicio = {"Publico", "Privado"};
        for (int i = 0; i < capacidad; i++) {
            RServicio[i] = servicio[(int) (Math.floor(Math.random() * ((servicio.length - 1) - 0 + 1) + 0))];
        }
        return RServicio;
    }
//Nombres
    /**
     * Metodo para obtener los nombres aleatoriamente
     * @param cantidad
     * @return 
     */
    public static String[] RNames(int cantidad) {
        String[] nombresAleatorios = new String[cantidad];

        String[] nombres = {"Andrea", "David", "Baldomero", "Balduino", "Baldwin", "Baltasar", "Barry", "Bartolo",
            "Bartolomé", "Baruc", "Baruj", "Candelaria", "Cándida", "Canela", "Caridad", "Carina", "Carisa",
            "Caritina", "Carlota", "Baltazar"};
        String[] apellidos = {"Gomez", "Guerrero", "Cardenas", "Cardiel", "Cardona", "Cardoso", "Cariaga", "Carillo",
            "Carion", "Castiyo", "Castorena", "Castro", "Grande", "Grangenal", "Grano", "Grasia", "Griego",
            "Grigalva"};

        for (int i = 0; i < cantidad; i++) {
            nombresAleatorios[i] = nombres[(int) (Math.floor(Math.random() * ((nombres.length - 1) - 0 + 1) + 0))] + " "
                    + apellidos[(int) (Math.floor(Math.random() * ((apellidos.length - 1) - 0 + 1) + 0))];
        }
        return nombresAleatorios;
    }

//Dirección
    /**
     * Metodo para obtener la direccion aleatoria
     * @param capacidad
     * @return 
     */
    public static String[] RDireccion(int capacidad) {
        String[] RDireccion = new String[capacidad];
        String[] direccion = {"Medellin","Bogota","Boyaca","Girardot","Facatativa","Rosal","Cartagena","Cucunuba","Choconta",
        "Tunja","Chiquinquira","La vega", "Villeta", "Bucaramanga", "Villavicencio"};
        for (int i = 0; i < capacidad; i++) {
            RDireccion[i] = direccion[(int) (Math.floor(Math.random() * ((direccion.length - 1) - 0 + 1) + 0))];
        }
        return RDireccion;
    }
//Aseguradora
    /**
     * Metodo para obtener el seguro aleatoriamente
     * @param capacidad
     * @return 
     */
      public static String[] RSeguro(int capacidad) {
        String[] RSeguro = new String[capacidad];
        String[] seguro = {"Grupo Sura","Allianz","Aseguradora Solidaria","Mapfre","Liberty Seguros"};
        for (int i = 0; i < capacidad; i++) {
            RSeguro[i] = seguro[(int) (Math.floor(Math.random() * ((seguro.length - 1) - 0 + 1) + 0))];
        }
        return RSeguro;
    }
//Fecha Final o Inicial soat 
      /**
       * Metodo para la fecha actual aleatoriamente
       * @return 
       */
      public static String RFechaActual() {
        byte dia = (byte) (Math.random() * 28 + 1);
        byte mes = (byte) (Math.random() * 12 + 1);
        int anio = (int) (Math.random() * 5 + 2016);
        String fecha = dia + "-" + mes + "-"  + anio;
        return  fecha;
      }
      
}
