/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfazApp;

import DataStructures.*;
import Entities.*;
import Utilities.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import static Utilities.RndInfo.*;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Calendar;


/**Descripcion de la clase Main o SDSIT
 * @author Edwin Alejandro Forero Gomez
 * @author Diego Andres Contreras Perez
 * @author Camilo Andres Rodriguez Medina
 * @author David Esteban Forero Espinosa
 */
public class SDSIT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {

        try {
            BST arbol = new BST();

            String menu = "Bienvenido, seleccione la operación a realizar: \n\n1) Insertar elementos \n2) Consultar vehículo \n3) Imprimir registro"
                    + "\n4) Salir";
            String title = "Sis. Auto. de Detección y sanción de Infracciones de Tránsito";
            byte option;

            Log log;
            Vehicle vehiculo;
            Person persona;
            Soat soat;
            int j = 0;

            do {
                option = Byte.parseByte(JOptionPane.showInputDialog(null, menu, title, 3));

                switch (option) {
                    case 1://Insertar
                        int n;
                        do {
                            n = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad de vehículos a registrar", "Agregar registros", 3));
                        } while (n < 1);
                        String[] marca = RndInfo.RMarca(n);
                        String[] modelo = RndInfo.RModelo(n);
                        String[] color = RndInfo.RColor(n);
                        String[] servicio = RndInfo.RServicio(n);
                        String[] nombres = RndInfo.RNames(n);
                        String[] Direccion = RndInfo.RDireccion(n);
                        String[] seguros = RndInfo.RSeguro(n);
                        long id;
                        long numeroT;
                        Date fechaF;
                        
                        for (int i = 0; i < n; i++) {
                            String placa = RPlacas();
                           
                            log = (Log) arbol.get(placa);

                            if (log == null) {
                                
                                SimpleDateFormat objSDF = new SimpleDateFormat("dd-mm-yyyy");
                                Date dt = objSDF.parse(RndInfo.RFechaActual());
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(dt);
                                cal.add(Calendar.YEAR, 1);
                                fechaF = cal.getTime();
                                soat = new Soat(seguros[i],dt,fechaF);
                                id = (j + 1) * 10 + 1000000;
                                numeroT = (j+1)*3100000 + 20000;
                                persona = new Person(nombres[i],Direccion[i],nombres[i].replace(" ","").toLowerCase()+"@gmail.com",id, numeroT);
                                vehiculo = new Vehicle(placa, marca[i],modelo[i], "1600",color[i],servicio[i], persona, soat);

                                j++;
                                log = new Log(vehiculo);
                            }

                            log.newFault();
                            arbol.put(log.getVehiculo().getPlaca(), log);
                        }

                        JOptionPane.showMessageDialog(null, n + " registro(s) agregado(s) con éxito", "Agregar registros", 1);
                        break;
                    case 2://Buscar
                        String placa = JOptionPane.showInputDialog(null, "Ingrese la placa del vehículo a consultar:", "Consultar estado", 3);

                        log = (Log) arbol.get(placa);

                        if (log == null) {
                            JOptionPane.showMessageDialog(null, "La placa del vehículo no se encuetra registrada en el sistema.", "Consultar estado", 1);
                        } else {
                            JOptionPane.showMessageDialog(null, "Información de automotor:\n" + log, "Consultar estado", 2);
                        }

                        break;
                    case 3://Imprimir
                        System.out.println("------------------------REGISTRO DE TODOS LOS VEHÍCULOS------------------------"
                                + arbol.inOrder());
                        JOptionPane.showMessageDialog(null, "Revisa la consola..", "Imprimir registros", 1);
                        break;
                    case 4://Salir
                        System.exit(0);
                        break;
                    default:
                }
            } while (option != 4);
        } catch (NumberFormatException nfe) {
            javax.swing.JOptionPane.showMessageDialog(null, "Está Saliendo del Programa");
        }
    }

}
