/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructures;

import java.util.Iterator;

/**
 * Descripcion de la clase stack
 *
 * @author edwin
 */
public class Stack<Item> implements Iterable<Item> {

    /**
     * Declaracion de los atributos
     */
    private Node first;
    private int N;

    /**
     * Clase privada de tipo node anidada
     */
    private class Node {  // nested class to define nodes      

        /**
         *Declaracion de atributos
         */
        private Item item;
        private Node next;
    }
    
    /**
     * Metodo boolean para mirar si esta vacio
     * @return 
     */
    public boolean isEmpty() {
        return first == null;
    }
    /**
     * metodo copy nos retorna el stack
     * @param a
     * @return 
     */
    public Stack copy(Stack a) {
        Stack temp = new Stack();
        temp = a;

        return temp;
    }
    /**
     * Metodo size 
     * Nos retorna el tamano
     * @return 
     */
    public int size() {
        return N;
    }
    /**
     * Metodo push para agregar datos
     * @param item 
     */
    public void push(Item item) {
        Node oldfirst = first;
        first = new Node();
        first.item = item;
        first.next = oldfirst;
        N++;
    }
    /**
     * Metodo pop para eliminar datos
     * @return 
     */
    public Item pop() {
        Item item = first.item;
        first = first.next;
        N--;
        return item;
    }
    /**
     * Iterador de la clase stack
     * @return 
     */
    @Override
    public Iterator<Item> iterator() {
        return new ListIterator();
    }
    /**
     * Clase anidada de la clase stack que implementa el iterador
     */
    private class ListIterator implements Iterator<Item> {
        /**
         * Declaracion del atributo
         */
        private Node current = first;
        /**
         * Metodo hasnext
         * Nos retorna un valor boolean
         * @return 
         */
        public boolean hasNext() {
            return current != null;
        }
        /**
         * Metodo next
         * nos retorna un objeto de tipo item
         * @return 
         */
        public Item next() {
            Item item = current.item;
            current = current.next;
            return item;
        }
    }
    /**
     * Metodo toString 
     * para la impresion de todos los datos
     * @return 
     */
    @Override
    public String toString() {

        Iterator it = this.iterator();
        String temp = "";

        while (it.hasNext()) {
            temp += it.next() + "\n";
        }

        return temp;
    }

}
