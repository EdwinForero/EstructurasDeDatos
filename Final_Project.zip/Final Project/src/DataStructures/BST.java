/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructures;

/**Descripcion de la Clase DataStructures
 * 
 * @param <String>
 * @param <Item> 
 */
public class BST<String extends Comparable<String>, Item> {
    /**
     * Declaracion de atributos 
     */
    private Node root;
    /**
     * Clase anidada privada 
     */
    private class Node {
        /**
         * Declaracion de atributos de la clase anidada
         */
        private String key;

        private Item val;
        private Node left, right;
        private int N;
        /**
         * Constructor de la clase anidada
         * @param key
         * @param val
         * @param N 
         */
        private Node(String key, Item val, int N) {
            this.key = key;
            this.val = val;
            this.N = N;
        }
    }
    /**
     * Metodo Size
     * @return 
     */
    public int size() {
        return size(root);
    }
    /**
     * Metodo size
     * Nos retorna si esta vacio algun nodo
     * @param x
     * @return 
     */
    private int size(Node x) {
        if (x == null) {
            return 0;
        } else {
            return x.N;
        }
    }
    /**
     * Metodo GetRoot
     * 
     * @return 
     */
    public Node getRoot() {
        Node node = root;
        return node;
    }
    /**
     * Metodo get recursivo
     * @param key
     * @return 
     */
    public Item get(String key) {
        return get(root, key);
    }
    /**
     * Metodo get
     * Devuelve el valor que se quiere obtener 
     * @param x
     * @param key
     * @return 
     */
    private Item get(Node x, String key) {
        if (x == null) {
            return null;
        }
        int cmp = key.compareTo(x.key);
        if (cmp < 0) {
            return get(x.left, key);
        } else if (cmp > 0) {
            return get(x.right, key);
        } else {
            return x.val;
        }
    }
    /**Metodo put
     * Metodo recursivo que tiene 2 parametros
     *
     * @param key
     * @param val 
     */
    public void put(String key, Item val) {
        root = put(root, key, val);
    }
    /**
     * Metodo para agregar en el BST
     * @param x
     * @param key
     * @param val
     * @return 
     */
    private Node put(Node x, String key, Item val) {
        if (x == null) {
            return new Node(key, val, 1);
        }
        int cmp = key.compareTo(x.key);
        if (cmp < 0) {
            x.left = put(x.left, key, val);
        } else if (cmp > 0) {
            x.right = put(x.right, key, val);
        } else {
            x.val = val;
        }
        x.N = size(x.left) + size(x.right) + 1;
        return x;
    }
    /**
     * Metodo recursivo para obtener el arbol ordenado
     * @return 
     */
    public String inOrder() {
        return inOrder(root, (String) "");
    }
    /**
     * Metodo inOrder
     * Metodo que nos pide dos parametros y nos devuelve un String
     * @param root
     * @param a
     * @return 
     */
    private String inOrder(Node root, String a) {

        if (root == null) {
            return a;
        }

        Stack s = new Stack();
        Node currentNode = root;

        while (!s.isEmpty() || currentNode != null) {

            if (currentNode != null) {
                s.push(currentNode);
                currentNode = currentNode.left;
            } else {
                Node n = (Node) s.pop();
                a += n.val.toString();
                currentNode = n.right;
            }
        }

        return a;
    }
}
