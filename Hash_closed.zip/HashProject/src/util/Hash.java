package util;

/**
 *
 * @author Epsilon
 */
public class Hash {
    int dato;
    int estado; //0 = Vacío, 1 = Eliminado, 2 = Ocupado
    
    public Hash(){
        estado = dato = 0;
    }
    
    public static int funcion(int n, int m, int i) {
        int h1 = n % m;
        int h2 = 1 + (n % (m-2));
        int h = (h1 + i*h2) % m;
        System.out.println("Calculando index del num " + n + "... \nh1(n)=" + h1 + " h2(n)=" + h2 + " Index:" + h + " Intento #" + i);
        return h;
    }

    public static boolean insertaHash(Hash[] h, int m, int n) {
        boolean i = false;
        int a = 0, max = 2147483647;
        
        do {
            int j = funcion(n, m, a);
            if (h[j].estado == 0 || h[j].estado == 1) {
                h[j].dato = n;
                h[j].estado = 2;
                i = true;
            }
            a++;
        } while (a<max && !i);
        return i;
    }

    public static int buscaHash(Hash[] h, int m, int n) {
        int a = 0, j, max = 2147483647;
        
        do{
            j = funcion(n, m, a);
            if (h[j].estado == 0) {
                return -1;
            } else if (h[j].dato == n) {
                if (h[j].estado == 1) {
                    return -1;
                } else {
                    return j;
                }
            } else {
                a++;
            }
        }while (a < max);
        
        return -1;
    }

    public static boolean eliminaHash(Hash[] h, int m, int n) {
        int i = buscaHash(h, m, n);
        if (i == -1) {
            return false;
        } else {
            h[i].estado = 1;
            return true;
        }
    }

    @Override
    public String toString() {
        return dato + " {estado: " + estado + '}';
    }
    
    
}
